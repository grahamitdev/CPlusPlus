#include "add.h"

double Add::getResult()
{
	return numA+numB;
}
