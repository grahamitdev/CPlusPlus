#ifndef _SUB_H_
#define _SUB_H_
#include "operation.h"

class Sub:public Operation
{
public:
	virtual double getResult();


};
#endif
