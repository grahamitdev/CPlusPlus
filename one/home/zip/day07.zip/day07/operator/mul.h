#ifndef _MUL_H_
#define _MUL_H_

#include "operation.h"

class Mul:public Operation
{
public:
	virtual double getResult();

};
#endif
