#ifndef _ADD_H_
#define _ADD_H_
#include "operation.h"

class Add:public Operation
{
public:
	virtual double getResult();
};
#endif
