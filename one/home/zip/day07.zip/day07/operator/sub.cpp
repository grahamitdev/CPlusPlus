#include "sub.h"

double Sub::getResult()
{
	return numA-numB;
}
