#include "mul.h"


double Mul::getResult()
{
	return numA*numB;

}
