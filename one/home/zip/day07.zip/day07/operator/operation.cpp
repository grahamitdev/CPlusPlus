#include "operation.h"


void Operation::setNumA(const double& numA)
{
	this->numA = numA;
}
void Operation::setNumB(const double& numB)
{
	this->numB = numB;
}
