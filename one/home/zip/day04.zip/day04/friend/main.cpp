#include "Animal.h"



int main(void)
{
	Cat cat(3);
	Dog dog(5);
	sumWeight(cat,dog);


	return 0;
}
