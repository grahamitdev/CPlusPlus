#include "engine.h"

void Engine::addOil()
{
	cout << "jiayou" << endl;
}

void Engine::boostUp()
{
	cout << "qidong" << endl;
}

void Car::addOil()
{
	cout << "car jiayou" << endl;
}

void Car::boostUp()
{
	cout << "car qidong" << endl;
}
